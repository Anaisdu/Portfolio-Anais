# LICENSE #

### Theme License ###

Dashkit is designed, developed and supported by Good Themes.

Use of this theme is governed by the license terms of the Bootstrap Themes platform (https://themes.getbootstrap.com/licenses/)


### Font License ###

Cerebri Sans is included with the Dashkit theme, though it is subject to a different license. 

The license summary is "You, the purchaser of Dashkit, may use Cerebri Sans in the context of this theme to build and publish your own site, but cannot redistribute the font source". To read the entire license agreement, check it out here: https://www.dropbox.com/s/9a2u5naja7xlo90/AMP_Bootstrap_Font%20License_29062018-signed.pdf?dl=0

On a personal note, usage of the beautiful Cerebri Sans, is made possible solely because of the gracious nature of Alfredo Marco Pradil, owner of Hanken Design (https://hanken.co). Please check him our on Behance (behance.net/pradil) and support his work!

### Questions? ###

Don't hesitate to hit us up with questions – support@goodthemes.co.